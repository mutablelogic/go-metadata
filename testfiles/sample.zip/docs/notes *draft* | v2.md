# Notes

Some notes.
